"""Rebuild the requested additions while preserving all original archive entries.

Usage: Python 3.12 rebuild.py --base base-original.exe --output ../AutoCropVideos.exe
Requires PyInstaller. No decompilation or replacement of the base editor.
"""
from pathlib import Path
import argparse
import hashlib
import json
import marshal
import sys
from datetime import datetime, timezone
from PyInstaller.archive.readers import CArchiveReader
from PyInstaller.archive.writers import CArchiveWriter
from PyInstaller.utils.win32.winutils import update_exe_pe_checksum

ORIGINAL_SHA256 = 'a5482bd2473147b3c0660a9eb71e1d898c4e6b9cbb2a0a6c09d5c039bd289095'


class PreservingArchiveWriter(CArchiveWriter):
    def _write_entry(self, fp, entry):
        name, payload, compressed, kind = entry
        return self._write_blob(fp, payload, name, kind, compress=compressed)


VERIFY_HARNESS = r'''
def verify_packaged_runtime(report_path):
    import json, os, time, hashlib
    from pathlib import Path
    from PySide6.QtGui import QFontDatabase, QFont
    from PySide6.QtWidgets import QTabWidget
    root = Path(report_path).resolve().parent
    report = {'ok': False}
    window = None
    app = base.QApplication([])
    try:
        base.apply_theme(app)
        QFontDatabase.addApplicationFont('C:/Windows/Fonts/segoeui.ttf')
        app.setFont(QFont('Segoe UI', 9))
        window = base.Window()
        window.start_thumbnails = lambda: None
        paths = []
        for index in range(3):
            path = root / ('packaged_video_' + str(index) + '.mp4')
            writer = base.cv2.VideoWriter(str(path), base.cv2.VideoWriter_fourcc(*'mp4v'), 10, (320, 240))
            assert writer.isOpened()
            for frame_index in range(15):
                frame = base.np.zeros((240, 320, 3), base.np.uint8)
                frame[40:200, 40:280] = (30, 150, 220)
                frame[70:130, 80+frame_index:150+frame_index] = (200, 40, 100)
                writer.write(frame)
            writer.release()
            paths.append(str(path))
        window.import_paths(paths)
        window.files.setCurrentRow(0)
        window.files.item(0).setCheckState(Qt.Checked)
        window.files.item(1).setCheckState(Qt.Checked)
        window.files.item(2).setCheckState(Qt.Unchecked)
        window.show_crop(base.Crop(10, 20, 200, 180, .5))
        window.crops[paths[1]] = base.Crop(40, 40, 240, 160, .5)
        def wait_worker():
            deadline = time.monotonic() + 30
            while window.worker.isRunning():
                app.processEvents()
                time.sleep(.01)
                assert time.monotonic() < deadline, 'worker timeout'
            for _ in range(10):
                app.processEvents()
        window._confirm_selected()
        wait_worker()
        assert window.approved == set(paths[:2]), repr(window.approved)
        assert window.crops[paths[0]].w == 200
        assert window.crops[paths[1]].w == 240
        window.resize(1400, 940)
        window.show()
        app.processEvents()
        window.grab().save(str(root / '01-recorte-em-lote.png'))
        original_dialog = base.QFileDialog.getExistingDirectory
        chosen = []
        export_folder = root / 'packaged_exports'
        export_folder.mkdir(exist_ok=True)
        def choose(*args, **kwargs):
            chosen.append(args[1])
            return str(export_folder)
        base.QFileDialog.getExistingDirectory = choose
        try:
            window.download_selected()
            wait_worker()
            assert all(path in window.results for path in paths[:2]), window.status.text()
            first = Path(window.results[paths[0]])
            first_hash = hashlib.sha256(first.read_bytes()).hexdigest()
            window.download_current()
            wait_worker()
            second = Path(window.results[paths[0]])
            assert first != second
            assert hashlib.sha256(first.read_bytes()).hexdigest() == first_hash
            assert len(chosen) == 2
        finally:
            base.QFileDialog.getExistingDirectory = original_dialog
        cap = base.cv2.VideoCapture(str(second))
        ok, frame = cap.read()
        cap.release()
        assert ok and frame.shape[:2] == (180, 200), repr(frame.shape if ok else None)
        assert window._video_progress[paths[0]] == (100, 'Concluído')
        assert window._video_progress[paths[1]] == (100, 'Concluído')
        tabs = window.findChild(QTabWidget)
        tabs.setCurrentIndex(2)
        window._set_video_progress(paths[1], 42, 'Exportando')
        app.processEvents()
        window.grab().save(str(root / '02-progresso-na-lateral.png'))
        window._set_video_progress(paths[1], 100, 'Concluído')
        window.persist_session()
        window.close()
        window = base.Window()
        window.start_thumbnails = lambda: None
        assert set(paths[:2]).issubset(window.approved)
        assert window.crops[paths[0]].w == 200
        report.update(ok=True, checked_videos=2, unchanged_unchecked_video=True,
                      actual_batch_export=True, repeated_export_preserved=True,
                      dialogs=chosen, persisted=True, cropped_resolution=[200, 180],
                      runtime='bundled Python/Qt/OpenCV/FFmpeg')
    except BaseException as exc:
        import traceback
        report['error'] = str(exc)
        report['traceback'] = traceback.format_exc()
    finally:
        if window:
            if window.worker and window.worker.isRunning():
                window.cancel()
                window.worker.wait(5000)
            window.close()
        Path(report_path).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    return 0 if report['ok'] else 1
'''


def build(base_exe, output_exe, updates_path):
    if sys.version_info[:2] != (3, 12):
        raise RuntimeError('Use Python 3.12, matching the original runtime.')
    original_bytes = base_exe.read_bytes()
    if hashlib.sha256(original_bytes).hexdigest() != ORIGINAL_SHA256:
        raise RuntimeError('The original base executable does not match the verified 0.6.0 build.')
    if base_exe.resolve() == output_exe.resolve():
        raise ValueError('The original base cannot be overwritten.')
    archive = CArchiveReader(str(base_exe))
    update_text = updates_path.read_text(encoding='utf-8')
    launcher = (
        "import os\n"
        "_verify_report = os.environ.get('AUTOCROP_VERIFY_PACKAGE')\n"
        "if _verify_report:\n"
        "    os.environ['QT_QPA_PLATFORM'] = 'offscreen'\n"
        + update_text + '\n' + VERIFY_HARNESS + '\n'
        "install()\n"
        "if _verify_report:\n"
        "    raise SystemExit(verify_packaged_runtime(_verify_report))\n"
        "_AUTOCROP_LOCAL_NAME = 'AutoCropVideos-recorte-lote-v3'\n"
        "_OriginalLocalSocket = base.QLocalSocket\n"
        "_OriginalLocalServer = base.QLocalServer\n"
        "class _LocalSocket:\n"
        "    def __init__(self): self._socket = _OriginalLocalSocket()\n"
        "    def __getattr__(self, name): return getattr(self._socket, name)\n"
        "    def connectToServer(self, _name): return self._socket.connectToServer(_AUTOCROP_LOCAL_NAME)\n"
        "class _LocalServer:\n"
        "    def __init__(self, *args): self._server = _OriginalLocalServer(*args)\n"
        "    def __getattr__(self, name): return getattr(self._server, name)\n"
        "    def listen(self, _name): return self._server.listen(_AUTOCROP_LOCAL_NAME)\n"
        "base.QLocalSocket = _LocalSocket\n"
        "base.QLocalServer = _LocalServer\n"
        "_app = base.QApplication(__import__('sys').argv)\n"
        "_app.setApplicationName('AutoCropVideos')\n"
        "base.apply_theme(_app)\n"
        "_window = base.Window()\n"
        "_window.show()\n"
        "raise SystemExit(_app.exec())\n"
    )
    new_launch = marshal.dumps(compile(launcher, 'autocrop_requested_updates.py', 'exec'))
    entries = []
    for option in archive.options:
        entries.append((option, b'', False, 'o'))
    for name, (_, _, _, compressed, kind) in archive.toc.items():
        entries.append((name, new_launch if name == 'launch' else archive.extract(name), compressed, kind))
    payload = output_exe.with_suffix('.build-payload.pkg')
    try:
        PreservingArchiveWriter(str(payload), entries, 'python312.dll')
        output_exe.write_bytes(original_bytes[:archive._start_offset] + payload.read_bytes())
        update_exe_pe_checksum(str(output_exe))
    finally:
        payload.unlink(missing_ok=True)
    result = CArchiveReader(str(output_exe))
    if result.options != archive.options:
        raise AssertionError('Original bootloader options changed.')
    preserved = []
    for name in archive.toc:
        if name != 'launch':
            if archive.extract(name) != result.extract(name):
                raise AssertionError('Original archive entry changed: ' + name)
            preserved.append(name)
    return {
        'version': '0.6.0-recorte-lote-20261108',
        'built_utc': datetime.now(timezone.utc).isoformat(),
        'original_exe_sha256': ORIGINAL_SHA256,
        'exe_sha256': hashlib.sha256(output_exe.read_bytes()).hexdigest(),
        'updates_sha256': hashlib.sha256(updates_path.read_bytes()).hexdigest(),
        'preserved_archive_entries': preserved,
        'original_pyz_unchanged': True,
        'original_source_available': False,
        'changes_source': 'manutencao/updates.py',
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', type=Path, default=Path(__file__).with_name('base-original.exe'))
    parser.add_argument('--output', type=Path, default=Path(__file__).parent.parent / 'AutoCropVideos.exe')
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    manifest = build(args.base, args.output, Path(__file__).with_name('updates.py'))
    args.output.with_name('build-manifest.json').write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(manifest, indent=2, ensure_ascii=False))
