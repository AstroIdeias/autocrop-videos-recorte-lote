"""Requested additions for the unchanged AutoCrop Videos 0.6.0 base.

The original Python modules remain byte-for-byte intact in PYZ.pyz.
This module installs only the three requested UI/workflow changes.
"""
from pathlib import Path
import threading

import autocrop.app as base
from PySide6.QtCore import QRect, QSize, Qt, QThread, Signal
from PySide6.QtGui import QColor, QPen
from PySide6.QtWidgets import (
    QStyledItemDelegate, QStyleOptionViewItem, QStyleOptionProgressBar,
    QStyle, QPushButton, QLabel, QVBoxLayout,
)


class VideoProgressDelegate(QStyledItemDelegate):
    """Keep Qt's original list rendering, including its checkboxes and icons."""

    def __init__(self, window):
        super().__init__(window.files)
        self.window = window

    def paint(self, painter, option, index):
        state = self.window._video_progress.get(index.data(Qt.UserRole))
        text_option = QStyleOptionViewItem(option)
        if state is not None:
            text_option.rect = option.rect.adjusted(0, 0, 0, -27)
        super().paint(painter, text_option, index)
        if state is not None:
            value, stage = state
            rect = QRect(option.rect.left() + 8, option.rect.bottom() - 24,
                         max(24, option.rect.width() - 16), 20)
            painter.save()
            painter.setClipRect(option.rect)
            painter.setPen(QPen(QColor('#3c526a')))
            painter.setBrush(QColor('#172633'))
            painter.drawRoundedRect(rect.adjusted(0, 0, -1, -1), 3, 3)
            if value:
                fill = rect.adjusted(1, 1, -1, -1)
                fill.setWidth(round(fill.width() * value / 100))
                painter.setPen(Qt.NoPen)
                painter.setBrush(QColor('#18866f'))
                painter.drawRoundedRect(fill, 2, 2)
            painter.setFont(option.font)
            painter.setPen(QColor('#ffffff'))
            text = option.fontMetrics.elidedText(f'{stage} • {value}%', Qt.ElideRight, rect.width() - 8)
            painter.drawText(rect.adjusted(4, 0, -4, 0), Qt.AlignCenter, text)
            painter.restore()


class ConfirmCropsWorker(QThread):
    confirmed = Signal(str, object, object, object)
    failed = Signal(str, str)
    item_progress = Signal(str, int, str)
    progress = Signal(int)

    def __init__(self, paths, candidates, identities):
        super().__init__()
        self.paths = list(paths)
        self.candidates = dict(candidates)
        self.identities = dict(identities)
        self.cancel = threading.Event()
        self.completed = self.errors = 0

    def run(self):
        for number, path in enumerate(self.paths):
            if self.cancel.is_set():
                break
            try:
                self.item_progress.emit(path, 0, 'Confirmando recorte')
                identity = base.fingerprint(path)
                previous_identity = self.identities.get(path)
                if previous_identity is not None and identity != previous_identity:
                    raise ValueError('Arquivo de origem alterado; importe novamente ou revise o recorte.')
                cap = base.cv2.VideoCapture(path)
                try:
                    ok, frame = cap.read()
                finally:
                    cap.release()
                if not ok:
                    raise ValueError('Falha ao ler o vídeo; recorte não confirmado.')
                height, width = frame.shape[:2]
                candidate = self.candidates.get(path)
                if candidate is None:
                    candidate = base.analyze(
                        path, cancel=self.cancel,
                        progress=lambda value, p=path: self.item_progress.emit(
                            p, min(95, int(value)), 'Analisando recorte'))
                base.validate(candidate, width, height)
                if self.cancel.is_set():
                    break
                if base.fingerprint(path) != identity:
                    raise ValueError('Arquivo alterado durante o recorte; revise novamente.')
                candidate = base.Crop(candidate.x, candidate.y, candidate.w, candidate.h, 1.0)
                self.confirmed.emit(path, candidate, (width, height), identity)
                self.completed += 1
                self.item_progress.emit(path, 100, 'Recorte pronto')
            except base.Cancelled:
                break
            except Exception as exc:
                self.errors += 1
                self.failed.emit(path, str(exc))
                self.item_progress.emit(path, 0, 'Erro no recorte')
            self.progress.emit(round((number + 1) * 100 / len(self.paths)))


def _set_video_progress(self, path, value, stage):
    self._video_progress[path] = (max(0, min(100, int(value))), stage)
    for row in range(self.files.count()):
        item = self.files.item(row)
        if item.data(Qt.UserRole) == path:
            item.setSizeHint(QSize(270, 128))
            self.files.viewport().update(self.files.visualItemRect(item))
            break


def _confirm_selected(self):
    if self.busy():
        return
    paths = list(self.checked_paths())
    if not paths:
        self.status.setText('Marque pelo menos um vídeo para recortar.')
        return
    candidates = {p: self.drafts.get(p) or self.crops.get(p) for p in paths}
    if self.path in paths and self.frame is not None:
        candidates[self.path] = base.Crop(
            *(self.fields[key].value() for key in ('x', 'y', 'w', 'h')), 1.0)
    self.pause_preview()
    worker = ConfirmCropsWorker(paths, candidates, self.identities)
    self.worker = worker
    self._progress_paths = paths
    worker.confirmed.connect(self._receive_confirmed_crop)
    worker.failed.connect(self._crop_failed)
    worker.item_progress.connect(self._set_video_progress)
    worker.progress.connect(self.progress.setValue)
    worker.finished.connect(self._confirm_crops_done)
    for path in paths:
        self._set_video_progress(path, 0, 'Aguardando recorte')
    for control in self.controls:
        control.setEnabled(False)
    self.files.setEnabled(False)
    self.preview.setEnabled(False)
    self.templates.setEnabled(False)
    self.quality.setEnabled(False)
    for spin in self.fields.values():
        spin.setEnabled(False)
    self.undo_shortcut.setEnabled(False)
    self.redo_shortcut.setEnabled(False)
    self.cancel_button.setEnabled(True)
    self.progress.setValue(0)
    self.status.setText(f'Confirmando o recorte de {len(paths)} vídeo(s) marcado(s)…')
    worker.start()


def _receive_confirmed_crop(self, path, crop, dimensions, identity):
    self.dimensions[path] = dimensions
    self.ensure_history(path)
    self.crops[path] = crop
    self.drafts.pop(path, None)
    self.approved.add(path)
    self.identities[path] = identity
    self.record(path, confirm=True)
    self.mark_item(path, 'Recorte pronto')
    if self.path == path:
        self.show_crop(crop)


def _crop_failed(self, path, reason):
    self.approved.discard(path)
    self.mark_item(path, 'Erro no recorte: ' + reason)
    self.schedule_session()


def _confirm_crops_done(self):
    worker = self.worker
    self.done()
    self.files.setEnabled(True)
    for path in worker.paths:
        value, stage = self._video_progress.get(path, (0, ''))
        if stage in ('Aguardando recorte', 'Analisando recorte', 'Confirmando recorte'):
            self._set_video_progress(path, value, 'Cancelado')
    self.batch_label.setText(
        f'Recortes prontos: {worker.completed}/{len(worker.paths)} • Erros: {worker.errors}')
    self.status.setText(
        f'{"Recorte cancelado" if worker.cancel.is_set() else "Recortes confirmados"}. '
        f'{worker.completed} pronto(s); {worker.errors} erro(s).')
    current_crop = self.drafts.get(self.path) or self.crops.get(self.path)
    if self.frame is not None and current_crop is not None:
        self.show_crop(current_crop)
    self.update_history_buttons()
    self.schedule_session()


def _download_current(self):
    """Ask for the folder every time, including repeated exports of ready videos."""
    if self.busy():
        return
    path = self.path
    if not path or self.frame is None:
        self.status.setText('Selecione um vídeo para baixar.')
        return
    try:
        crop = base.Crop(*(self.fields[key].value() for key in ('x', 'y', 'w', 'h')), 1.0)
        height, width = self.frame.shape[:2]
        base.validate(crop, width, height)
        layout = self.composition_drafts.get(path) or self.compositions.get(path)
        if layout:
            layout = layout.clone()
            layout.validate()
        if self.identities.get(path) != base.fingerprint(path):
            raise ValueError('O vídeo de origem foi alterado. Abra-o novamente antes de baixar.')
        folder = base.QFileDialog.getExistingDirectory(
            self, 'Escolher pasta de saída para baixar vídeo', self.output)
        if not folder:
            return
        if not base.allowed_output(folder):
            self.status.setText('Escolha um destino fora da pasta de instalação.')
            return
        self.output = folder
        self.output_label.setText(folder)
        self.schedule_session()
        target = Path(folder) / (Path(path).stem + '_final.mp4')
        self.start(folder, [path], download=(target, crop, layout))
    except (ValueError, OSError) as exc:
        self.status.setText(str(exc))


def install():
    cls = base.Window
    if getattr(cls, '_requested_updates_installed', False):
        return
    cls._requested_updates_installed = True
    original_init = cls.__init__
    original_refresh = cls.refresh_item
    original_item_progress = cls.item_progress
    original_start = cls.start
    original_received = cls.received
    original_done = cls.done

    def init(self, *args, **kwargs):
        self._video_progress = {}
        original_init(self, *args, **kwargs)
        self.files.setItemDelegate(VideoProgressDelegate(self))
        self.crop_selected_button = QPushButton('✂ Recortar selecionados')
        self.crop_selected_button.setObjectName('primary')
        self.crop_selected_button.setToolTip(
            'Confirma o recorte próprio de cada vídeo marcado. '
            'Vídeos sem seleção são analisados antes de confirmar.')
        self.crop_selected_button.clicked.connect(self._confirm_selected)
        self.controls.append(self.crop_selected_button)
        sidebar = self.files.parentWidget().layout()
        # The original sidebar is a nested layout, not necessarily its parent's layout.
        def containing(layout, widget):
            for i in range(layout.count()):
                entry = layout.itemAt(i)
                if entry.widget() is widget:
                    return layout
                if entry.layout():
                    result = containing(entry.layout(), widget)
                    if result:
                        return result
            return None
        sidebar = containing(self.centralWidget().layout(), self.files)
        if sidebar is None:
            raise RuntimeError('Não foi possível localizar a lista de vídeos.')
        sidebar.insertWidget(sidebar.indexOf(self.files), self.crop_selected_button)
        # Move total progress and summary to the sidebar; each file gets its own bar.
        self.file_progress.hide()
        self.file_progress_label.hide()
        self.batch_label.setWordWrap(True)
        self.batch_label.setMinimumWidth(0)
        self.batch_label.setMaximumWidth(270)
        sidebar.insertWidget(sidebar.indexOf(self.files) + 1, self.progress)
        sidebar.insertWidget(sidebar.indexOf(self.progress) + 1, self.batch_label)
        self.progress.setFormat('Fila: %p%')
        self.setWindowTitle('AutoCrop Vídeos — Recorte em lote')

    def refresh(self, item, path, message=''):
        original_refresh(self, item, path, message)
        if path in self._video_progress:
            item.setSizeHint(QSize(270, 128))

    def item_progress(self, path, value, stage):
        original_item_progress(self, path, value, stage)
        self._set_video_progress(path, value, stage)

    def start(self, output=None, paths=None, download=None, batch_destinations=None):
        if self.busy():
            return
        selected = list(paths if paths is not None else self.paths())
        old_worker = self.worker
        original_start(self, output, paths, download, batch_destinations)
        if self.worker is not old_worker:
            self._progress_paths = selected
            for path in selected:
                self._set_video_progress(path, 0, 'Aguardando')

    def received(self, path, crop, message):
        original_received(self, path, crop, message)
        value, stage = self._video_progress.get(path, (0, ''))
        if message.startswith('Erro'):
            self._set_video_progress(path, value, 'Erro')
        elif message.startswith('Cancel'):
            self._set_video_progress(path, value, 'Cancelado')
        elif message.startswith('Export'):
            self._set_video_progress(path, 100, 'Concluído')

    def done(self):
        original_done(self)
        for path in getattr(self, '_progress_paths', []):
            value, stage = self._video_progress.get(path, (0, ''))
            if self.worker and self.worker.cancel.is_set() and stage not in ('Concluído', 'Erro', 'Recorte pronto', 'Erro no recorte'):
                self._set_video_progress(path, value, 'Cancelado')

    cls.__init__ = init
    cls.refresh_item = refresh
    cls.item_progress = item_progress
    cls.start = start
    cls.received = received
    cls.done = done
    cls.download_current = _download_current
    for function in (_set_video_progress, _confirm_selected, _receive_confirmed_crop,
                     _crop_failed, _confirm_crops_done):
        setattr(cls, function.__name__, function)

