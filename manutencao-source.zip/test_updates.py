from pathlib import Path
import os, sys, time, unittest, json, hashlib, subprocess
from unittest.mock import patch

ROOT = Path(__file__).parent.resolve()
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['AUTOCROP_DATA_DIR'] = str(ROOT / 'test_data')
sys.path.insert(0, str(ROOT / 'original_base'))
import autocrop.app as base
import updates
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFontDatabase, QFont
import numpy as np

updates.install()
app = QApplication.instance() or QApplication([])
QFontDatabase.addApplicationFont('C:/Windows/Fonts/segoeui.ttf')
app.setFont(QFont('Segoe UI', 9))
base.apply_theme(app)


def wait_worker(window, timeout=30):
    deadline = time.monotonic() + timeout
    while window.worker and window.worker.isRunning():
        app.processEvents()
        time.sleep(0.01)
        if time.monotonic() > deadline:
            window.cancel()
            window.worker.wait(5000)
            raise AssertionError('Worker timeout')
    for _ in range(8):
        app.processEvents()


def make_video(path, width=320, height=240):
    writer = base.cv2.VideoWriter(str(path), base.cv2.VideoWriter_fourcc(*'mp4v'), 10, (width, height))
    assert writer.isOpened()
    for i in range(15):
        frame = np.zeros((height, width, 3), np.uint8)
        frame[40:200, 40:280] = (30, 150, 220)
        frame[60:120, 70+i:150+i] = (200, 40, 100)
        writer.write(frame)
    writer.release()


class RequestedUpdatesTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (ROOT / 'test_data').mkdir(exist_ok=True)
        (ROOT / 'fixtures').mkdir(exist_ok=True)
        cls.paths = [str(ROOT / 'fixtures' / f'video_{i}.mp4') for i in range(4)]
        for path in cls.paths:
            make_video(Path(path))

    def setUp(self):
        with patch.object(base.Window, 'restore_session', lambda self: None):
            self.window = base.Window()
        self.window.start_thumbnails = lambda: None
        self.window.import_paths(self.paths)
        self.window.resize(1400, 900)
        self.window.show()
        app.processEvents()
        self.window.files.setCurrentRow(0)
        app.processEvents()
        for i in range(self.window.files.count()):
            self.window.files.item(i).setCheckState(Qt.Unchecked)

    def tearDown(self):
        if self.window.worker and self.window.worker.isRunning():
            self.window.cancel()
            wait_worker(self.window)
        self.window.session_timer.stop()
        self.window.close()
        app.processEvents()

    def check(self, *indexes):
        for i in indexes:
            self.window.files.item(i).setCheckState(Qt.Checked)

    def confirm(self, *indexes):
        self.check(*indexes)
        self.window._confirm_selected()
        wait_worker(self.window)

    def test_batch_confirms_only_checked_using_individual_selections(self):
        w = self.window
        p0, p1, p2, p3 = self.paths
        w.crops[p0] = base.Crop(10, 20, 200, 180, .5)
        w.show_crop(w.crops[p0])
        w.crops[p1] = base.Crop(40, 40, 240, 160, .4)
        w.drafts[p1] = base.Crop(60, 50, 200, 140, .2)
        w.crops[p2] = base.Crop(0, 0, 100, 100, .3)
        untouched = dict(w.compositions)
        hashes = {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in self.paths}
        self.confirm(0, 1)
        self.assertEqual(w.approved, {p0, p1})
        self.assertEqual((w.crops[p0].x, w.crops[p0].y, w.crops[p0].w, w.crops[p0].h), (10, 20, 200, 180))
        self.assertEqual((w.crops[p1].x, w.crops[p1].y, w.crops[p1].w, w.crops[p1].h), (60, 50, 200, 140))
        self.assertNotIn(p1, w.drafts)
        self.assertEqual(w.crops[p2].w, 100)
        self.assertNotIn(p3, w.crops)
        self.assertEqual(w.compositions, untouched)
        self.assertTrue(all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == hashes[p] for p in self.paths))
        self.assertIn('Recorte: Recorte pronto', w.files.item(1).text())
        self.assertTrue(w.files.isEnabled())
        self.assertTrue(w.crop_selected_button.isEnabled())

    def test_missing_selection_is_analyzed_and_confirmed(self):
        self.confirm(1)
        self.assertIn(self.paths[1], self.window.approved)
        self.assertEqual(self.window._video_progress[self.paths[1]], (100, 'Recorte pronto'))

    def test_empty_selection_does_not_start_worker(self):
        self.window._confirm_selected()
        self.assertIsNone(self.window.worker)
        self.assertIn('Marque pelo menos', self.window.status.text())

    def test_invalid_and_changed_files_stay_unapproved(self):
        w = self.window
        w.crops[self.paths[1]] = base.Crop(300, 0, 200, 100)
        w.identities[self.paths[2]] = {'invalid': True}
        self.confirm(1, 2)
        self.assertFalse(w.approved)
        self.assertEqual(w.worker.errors, 2)

    def test_cancel_keeps_unprocessed_files_unapproved(self):
        worker = updates.ConfirmCropsWorker(self.paths, {}, {})
        worker.cancel.set()
        worker.run()
        self.assertEqual(worker.completed, 0)
        self.assertEqual(worker.errors, 0)

    def test_sidebar_progress_persists_through_refresh_and_render(self):
        w = self.window
        p = self.paths[1]
        w.item_progress(p, 42, 'Exportando')
        w.mark_item(p, 'Em processamento')
        self.assertEqual(w._video_progress[p], (42, 'Exportando'))
        self.assertEqual(w.files.item(1).sizeHint().height(), 128)
        self.assertTrue(w.file_progress.isHidden())
        self.assertTrue(w.file_progress_label.isHidden())
        app.processEvents()
        self.assertLess(w.progress.geometry().left(), w.files.geometry().right())
        w.grab().save(str(ROOT / 'preview_updates.png'))

    def test_single_download_asks_folder_every_time_and_cancel_stops(self):
        w = self.window
        self.confirm(0)
        folder = ROOT / 'export_single'
        folder.mkdir(exist_ok=True)
        with patch.object(base.QFileDialog, 'getExistingDirectory', return_value=str(folder)) as dialog, \
             patch.object(w, 'start') as start:
            w.download_current()
            w.download_current()
            self.assertEqual(dialog.call_count, 2)
            self.assertEqual(start.call_count, 2)
            self.assertEqual(w.output, str(folder))
        with patch.object(base.QFileDialog, 'getExistingDirectory', return_value=''), \
             patch.object(w, 'start') as start:
            w.download_current()
            start.assert_not_called()

    def test_all_batch_export_buttons_ask_again_on_each_attempt(self):
        w = self.window
        self.confirm(0, 1, 2, 3)
        for i in (0, 1):
            w.files.item(i).setCheckState(Qt.Checked)
        for action in (w.download_selected, w.export_selected, w.export_all):
            with patch.object(base.QFileDialog, 'getExistingDirectory', return_value='') as dialog, \
                 patch.object(w, 'start') as start:
                action()
                action()
                self.assertEqual(dialog.call_count, 2, action.__name__)
                start.assert_not_called()

    def test_template_export_preserves_audio_layout_and_resolution(self):
        w = self.window
        runtime = Path(os.environ.get(
            'AUTOCROP_TEST_RUNTIME',
            r'D:/auto_crop_original/0.6.0-20261023-093257-995'))
        ffmpeg = runtime / '_internal' / 'bin' / 'ffmpeg.EXE'
        ffprobe = ffmpeg.with_name('ffprobe.EXE')
        audio_source = ROOT / 'fixtures' / 'with_audio.mp4'
        subprocess.run([str(ffmpeg), '-v', 'error', '-y', '-i', self.paths[0],
                        '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=44100:duration=1.5',
                        '-c:v', 'copy', '-c:a', 'aac', '-shortest', str(audio_source)],
                       check=True, capture_output=True, timeout=20)
        w.import_paths([str(audio_source)])
        w.files.setCurrentRow(w.files.count() - 1)
        app.processEvents()
        w.files.item(w.files.count() - 1).setCheckState(Qt.Checked)
        background = ROOT / 'fixtures' / 'background.png'
        base.cv2.imwrite(str(background), np.full((480, 320, 3), 220, np.uint8))
        layout = base.Composition(str(background), width=320, height=480,
                                  x=.1, y=.2, w=.8, h=.5)
        w.compositions[str(audio_source)] = layout
        snapshot = base.asdict(layout)
        self.confirm(w.files.count() - 1)
        output = ROOT / 'export_template'
        output.mkdir(exist_ok=True)
        with patch.object(base.QFileDialog, 'getExistingDirectory', return_value=str(output)):
            w.download_current()
            wait_worker(w, 45)
        target = w.results[str(audio_source)]
        info = json.loads(subprocess.run([str(ffprobe), '-v', 'error', '-show_streams',
                                         '-show_format', '-of', 'json', target],
                                        capture_output=True, check=True, timeout=15).stdout)
        video = next(s for s in info['streams'] if s['codec_type'] == 'video')
        audio = next(s for s in info['streams'] if s['codec_type'] == 'audio')
        self.assertEqual((video['width'], video['height']), (320, 480))
        self.assertEqual(audio['codec_name'], 'aac')
        self.assertAlmostEqual(float(info['format']['duration']), 1.5, delta=.2)
        self.assertEqual(base.asdict(w.compositions[str(audio_source)]), snapshot)

    def test_real_export_and_repeated_export_preserve_existing_file(self):
        w = self.window
        self.confirm(0)
        folder = ROOT / 'export_real'
        folder.mkdir(exist_ok=True)
        with patch.object(base.QFileDialog, 'getExistingDirectory', return_value=str(folder)):
            w.download_current()
            wait_worker(w, 45)
            self.assertIn(self.paths[0], w.results, w.status.text())
            first = Path(w.results[self.paths[0]])
            first_hash = hashlib.sha256(first.read_bytes()).hexdigest()
            w.download_current()
            wait_worker(w, 45)
            second = Path(w.results[self.paths[0]])
        self.assertNotEqual(first, second)
        self.assertEqual(hashlib.sha256(first.read_bytes()).hexdigest(), first_hash)
        cap = base.cv2.VideoCapture(str(second))
        try:
            ok, frame = cap.read()
            self.assertTrue(ok)
            self.assertEqual(frame.shape[:2], (240, 320))
        finally:
            cap.release()
        self.assertEqual(w._video_progress[self.paths[0]], (100, 'Concluído'))


if __name__ == '__main__':
    unittest.main(verbosity=2)
